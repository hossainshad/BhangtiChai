package com.example.bhangtichai;

import android.os.Bundle;
import android.content.res.Configuration;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText amountEditText;
    private TextView[] changeTextViews;
    private int amount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        amountEditText = findViewById(R.id.amountEditText);
        changeTextViews = new TextView[]{
                findViewById(R.id.textView10),
                findViewById(R.id.textView12),
                findViewById(R.id.textView14),
                findViewById(R.id.textView16),
                findViewById(R.id.textView18),
                findViewById(R.id.textView20),
                findViewById(R.id.textView22),
                findViewById(R.id.textView24)
        };
        if (savedInstanceState != null) {
            // Restore the amount from savedInstanceState
            amount = savedInstanceState.getInt("amount", 0);
            amountEditText.setText(String.valueOf(amount));
            for (int i = 0; i < changeTextViews.length; i++) {
                String changeQuantity = savedInstanceState.getString("changeTextView" + i, "0");
                changeTextViews[i].setText(changeQuantity);
            }
        }

    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("amount", amount);
        for (int i = 0; i < changeTextViews.length; i++) {
            outState.putString("changeTextView" + i, changeTextViews[i].getText().toString());
        }
    }


    public void onDigitButtonClick(View view) {
        String digit = ((TextView) view).getText().toString();
        amountEditText.getText().append(digit);
        int amount = Integer.parseInt(amountEditText.getText().toString());
        calculateChangeQuantities(amount);
    }

    public void onClearButtonClick(View view) {
        amountEditText.getText().clear();
        resetChangeQuantities();
    }

    private void resetChangeQuantities() {
        for (TextView textView : changeTextViews) {
            textView.setText("0");
        }
    }

    private void calculateChangeQuantities(int amount) {
        resetChangeQuantities();

        int[] denominations = {500, 100, 50, 20, 10, 5, 2, 1};
        for (int i = 0; i < denominations.length; i++) {
            int quantity = amount / denominations[i];
            changeTextViews[i].setText(String.valueOf(quantity));
            amount -= quantity * denominations[i];
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}